INSERT INTO `social_logos`(`name`) VALUES
('youtube-square'),
('youtube-play'),
('youtube'),
('wordpress'),
('yahoo'),
('whatsapp'),
('weixin'),
('vimeo-square'),
('vimeo'),

('twitter-square'),
('twitter'),

('telegram'),

('snapchat-square'),
('snapchat'),

('pinterest-square'),
('pinterest-p'),
('fa-pinterest'),

('linkedin-square'),
('linkedin'),

('instagram'),

('google-plus-official'),
('google-plus-square'),
('google-plus'),

('github-square'),
('github-alt'),
('github'),
('git-square'),

('facebook-square'),
('facebook-official'),
('facebook'),

('dribbble'),

('behance'),
('behance-square');