<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row mt-50">
			<div class="col-sm-4">
				
					<div class="card">
						<div class="card-body h-400 overflow-y-scroll">
							<?php if(count($conversations)): ?>
								<b>Conversations(<?php echo e(number_format(count($conversations))); ?>)</b> <br> <hr>
								
								<?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(route('user.conversation', ['id' => $conversation->id])); ?>" title="View Conversation">
										<div class="panel panel-default">
											<div class="panel-body">
												<div class="row">		
													<?php if($conversation->from_admin): ?>
														<div class="col-xs-3">
															<img src="<?php echo e(simba_coin()); ?>" alt="" class="img-responsive img-circle">
														</div>
														
														<div class="col-xs-9">
															<strong>Admin</strong> <br>
															<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
														</div>
													<?php else: ?>
														<?php if($conversation->from_id == $user->id): ?>
															<div class="col-xs-3">
																<img src="<?php echo e($conversation->to->thumbnail()); ?>" alt="" class="img-responsive img-circle">
															</div>
															<div class="col-xs-9">
																<strong><?php echo e($conversation->to->name); ?></strong><br>
																<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
															</div>
														<?php else: ?>
															<div class="col-xs-3">
																<img src="<?php echo e($conversation->from->thumbnail()); ?>" alt="" class="img-responsive img-circle">	
															</div>
															
															<div class="col-xs-9">
																<strong><?php echo e($conversation->from->name); ?></strong> <br>
																<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
															</div>
														<?php endif; ?>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							<?php else: ?>
								<p class="text-center mb-0">
									No Conversations
								</p>
							<?php endif; ?>
						</div>
					</div>
				
			</div>

			<div class="col-sm-8">
				<div class="card">
					<div class="card">
						<div class="card-body conversation-box h-400">
							<span class="no-conversation-selected centered">Please select a conversation to view</span>
						</div>
					</div>
				</div>
			</div>


		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>