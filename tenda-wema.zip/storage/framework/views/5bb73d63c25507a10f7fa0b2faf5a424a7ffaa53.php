<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($title); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li class="active"><?php echo e($title); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row py-50">
			<div class="col-sm-10 col-sm-offset-1">
				<div class="row">
					<div class="col-sm-12">	
						<?php if(auth()->check()): ?>
							<?php if(!auth()->user()->is_admin()): ?>
								<p class="">
									<a href="" data-toggle = "modal" data-target = "#create-post" class="button button-green  button-3d pull-right"><i class="fa fa-comment"></i> CREATE POST</a>
								</p>
								
								<?php echo $__env->make('pages.user.modals.create-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

							<?php endif; ?>
						<?php else: ?>
							<p>
								<a href="" data-toggle = "modal" data-target = "#login-modal"  class="button button-black  button-3d pull-right"><i class="fa fa-comment"></i> LOG IN TO POST</a>
							</p>

							<?php echo $__env->make('pages.user.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
															
						<?php endif; ?>
					</div>


				</div>

				<hr>

				<div class="row">
					<div class="col-sm-12">
						<?php if($posts->total()): ?>
							<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="panel">
									<div class="panel-body">
									    <h4 class="">
									    	<a href="<?php echo e(route('post', ['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a>
									    </h4>
									    
									    <p>
									    	<?php echo e(characters($post->content, 550)); ?> <br><br>
									    	<a href="<?php echo e(route('post', ['slug' => $post->slug])); ?>" class="pull-right">Read More</a>
									    </p>
										
										<p class="text-muted nobottommargin text-right">
											<small>
												Posted by 
												<a href="<?php echo e(route('user.show', ['username' => $post->user->username])); ?>">
													
													<?php echo e($post->user->name); ?>

												</a> | <?php echo e(simple_datetime($post->created_at)); ?> | Comments(<?php echo e(number_format(count($post->comments))); ?>)
											</small>
										</p>

									</div>


								</div>
								  
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<?php echo e($posts->links()); ?>

						<?php else: ?>
							<p>No Posts</p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>