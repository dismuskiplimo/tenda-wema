<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title full-width">
	            	<?php echo e($title); ?> 
	            	<a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-xs margin-right">
	            		<i class="fa fa-arrow-left"></i> BACK
	            	</a>
	            </h3>
	
				<?php if($transactions->total()): ?>
					<div class="row">
						<div class="col-sm-12">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>Date</th>
										<th>Transaction Code</th>
										<th>Amount</th>
										<th>Coins</th>
										<th>Medium</th>
										<th>Status</th>	
									</tr>
								</thead>

								<tbody>
									<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<tr>
											<td><?php echo e(simple_datetime($transaction->created_at)); ?></td>
											<td><?php echo e($transaction->transaction_code); ?></td>
											<td><?php echo e($transaction->currency); ?> <?php echo e(number_format($transaction->amount)); ?></td>
											<td><?php echo e(number_format($transaction->coins)); ?> Simba Coins</td>
											<td><?php echo e($transaction->medium); ?></td>
											<td><?php echo e($transaction->status); ?></td>		
											<td><?php echo e($transaction->description); ?></td>		
										</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
							
						</div>
						
					</div>

					<?php echo e($transactions->total()); ?>

					
				<?php else: ?>
					<i>No transactions</i>
				<?php endif; ?>
	            
	        </div>
	        
	    </div>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>