<div class="modal fade" id="purchase-coins">
  <div class="modal-dialog">
    <div class="modal-content">
      
        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Purchase Coins</h4>
        </div>
        
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-12 text-center">
              <h4>Please Choose Your Preferred Payment Method</h4>
            </div>

            <?php if($settings->mpesa_enabled->value): ?>
              <div class="col-sm-6 text-center">
              
                  <a href="" data-toggle="modal" data-target="#purchase-coins-mpesa" class="purchase-coins">
                    <img src="<?php echo e(custom_asset('images/payments/mpesa.png')); ?>" alt="" title="Mpesa" class="h-100">
                  </a>  
                
              </div>
            <?php endif; ?>
            
            <?php if($settings->paypal_enabled->value): ?>
              <div class="col-sm-6  text-center">
                  <a href="" data-toggle="modal" data-target="#purchase-coins-paypal" class="purchase-coins">
                    <img src="<?php echo e(custom_asset('images/payments/paypal.png')); ?>" alt="" title="Paypal" class="h-100">
                  </a>  
                
              </div>
            <?php endif; ?>

          </div>
          
        
          
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      
    </div>
  </div>
</div>

<?php echo $__env->make('pages.user.modals.buy-coins-mpesa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('pages.user.modals.buy-coins-paypal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>