<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($user->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Users</li>
				<li class="active"><?php echo e($user->name); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row my-50">
			<div class="col-sm-3">
				<?php echo $__env->make('includes.user.profile-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>

			<div class="col-sm-9">
				<h4>
					PHOTOS

					<?php if($me): ?>
						<a href="" class="button button-black pull-right mtn-10" data-toggle="modal" data-target="#add-user-photo-modal"><i class="fa fa-plus"></i> UPLOAD PHOTO</a>	
					<?php endif; ?>

				</h4>

				<div class="row mb-20">
					<?php if($photos->total()): ?>
						<?php
							$count = 0;
						?>

						<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
								$count++;
							?>

							<div class="col-sm-4">
								<a data-fancybox="gallery" href="<?php echo e($photo->photo()); ?>">
									<img src="<?php echo e($photo->thumbnail()); ?>" alt="<?php echo e($photo->user ? $photo->user->name : ''); ?>" class="img-responsive img-rounded">
								</a>

								<?php if($me): ?>
									<span class="delete-user-photo" title="Delete Photo">
										<form action="<?php echo e(route('user.photos.delete', ['id' => $photo->id])); ?>" method="POST">
											<?php echo csrf_field(); ?>
											<button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
										</form>
										
									</span>
								<?php endif; ?>
								
							</div>

							<?php if($count % 3 == 0): ?>
								</div>
								<div class="row mb-20">
							<?php endif; ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php echo e($photos->links()); ?>

					<?php else: ?>
						<div class="col-sm-12">
							<p class="text-muted">No photos</p>
						</div>
						
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>

	<?php if($me): ?>
		<?php echo $__env->make('pages.user.modals.add-user-photo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>