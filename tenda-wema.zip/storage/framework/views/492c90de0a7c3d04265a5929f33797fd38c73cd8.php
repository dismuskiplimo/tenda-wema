<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?> (<?php echo e(number_format($donations->total())); ?>)</h3>

	            <?php if($donations->total()): ?>
		            <table class="table table-striped">
		            	<thead>
		            		<tr>
		            			<th>Name</th>
		            			<th>Amount</th>
		            			<th>Preferred Method</th>
		            			<th>Country</th>
		            			<th>Phone</th>
		            			<th>Email</th>
		            			<th>Status</th>
		            			<th></th>
		            		</tr>

		            	</thead>

		            	<tbody>
		            		
		            		<?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($donation->fname . ' ' . $donation->lname); ?></td>
									<td>KES <?php echo e(number_format($donation->amount)); ?></td>
									<td><?php echo e($donation->method); ?></td>
									<td><?php echo e($donation->country); ?></td>
									<td><?php echo e($donation->phone); ?></td>
									<td><?php echo e($donation->email); ?></td>
									<td><?php echo e($donation->status()); ?></td>
									<td><a class = "btn btn-xs" href="<?php echo e(route('admin.support-cause', ['id' => $donation->id])); ?>"><i class="fa fa-eye"></i></a></td>
								</tr>
		            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            		
		            	</tbody>
		            </table>
		            	<?php echo e($donations->links()); ?>

		            <?php else: ?>
						<p>No Support cause requests</p>
		            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>