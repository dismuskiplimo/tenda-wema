<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title full-width">
	            	<?php echo e($title); ?> 
	            	<a href="<?php echo e(url()->previous()); ?>" class="btn btn-info btn-xs pull-right">
	            		<i class="fa fa-arrow-left"></i> BACK
	            	</a>
	            </h3>
	
				<?php if($simba_coin_logs->total()): ?>
					<div class="row">
						<div class="col-sm-12">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>Date</th>
										<th>Simba Coins</th>
										<th>Message</th>
										<th>Previous Balance</th>
										<th>New Balance</th>									
									</tr>
								</thead>

								<tbody>
									<?php $__currentLoopData = $simba_coin_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<tr>
											<td><?php echo e(simple_datetime($log->created_at)); ?></td>
											<td>
												<?php
													if($log->type == 'credit'){
														$class = 'text-success';	
													}else{
														$class = 'text-danger';
													}
												?>

												<span class="<?php echo e($class); ?>">
													<?php echo e($log->type == 'credit' ? '+' : '-'); ?> <?php echo e(number_format($log->coins)); ?>

												</span>
											</td>
											<td><?php echo e($log->message); ?></td>
											
											<td><?php echo e($log->previous_balance); ?></td>
											<td><?php echo e($log->current_balance); ?></td>
											
										</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
									
						</div>

					</div>

					<?php echo e($simba_coin_logs->links()); ?>

					
				<?php else: ?>
					<i>No simba coin logs</i>
				<?php endif; ?>
		        
	        </div> 
	        
	    </div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>