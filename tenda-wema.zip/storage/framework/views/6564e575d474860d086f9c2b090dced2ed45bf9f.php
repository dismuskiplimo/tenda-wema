                <?php echo $__env->make('includes.admin.right-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> <?php echo e(date('Y')); ?> &copy; <?php echo e(config('app.name')); ?> </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(custom_asset('js/admin/tether.min.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/admin/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/admin/bootstrap-extension.min.js')); ?>"></script>
    <!-- Sidebar menu plugin JavaScript -->
    <script src="<?php echo e(custom_asset('js/admin/sidebar-nav.min.js')); ?>"></script>
    <!--Slimscroll JavaScript For custom scroll-->
    <script src="<?php echo e(custom_asset('js/admin/jquery.slimscroll.js')); ?>"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(custom_asset('js/admin/waves.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/admin-chat.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/user/moment.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/user/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/user/bootstrap-datepicker.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(custom_asset('js/user/jquery.fancybox.min.js')); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(custom_asset('js/admin/custom.min.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/admin/custom.js')); ?>"></script>
    <script src="<?php echo e(custom_asset('js/tenda-wema.js')); ?>"></script>
</body>

</html>