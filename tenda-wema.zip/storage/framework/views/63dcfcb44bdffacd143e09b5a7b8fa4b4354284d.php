<?php $__env->startSection('content'); ?>
	<!-- Page Title
	============================================= -->
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($item->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li><a href="<?php echo e(route('community-shop')); ?>">Community Shop</a></li>
				<li class="active"><?php echo e($item->name); ?></li>
			</ol>
		</div>

	</section><!-- #page-title end -->

	<div class="container">
		<div class="row content-wrap">
			<div class="col-sm-8">
				<div class="card">
					<div class="card-body">
						<?php if($item->images->count()): ?>
							<div id="item-carousel" class="carousel slide" data-ride="carousel">
								<!-- Indicators -->
								<ol class="carousel-indicators">
									

									<?php for($cnt = 0; $cnt < count($item->images); $cnt++): ?>
										
										<li data-target="#item-carousel" data-slide-to="<?php echo e($cnt); ?>" class="<?php echo e($cnt == 0 ? 'active' : ''); ?>"></li>
										
									<?php endfor; ?>
									
									
								</ol>

								<!-- Wrapper for slides -->
								<div class="carousel-inner" role="listbox">
									<?php
										$cnt = 0;
									?>

									<?php $__currentLoopData = $item->images()->orderBy('created_at', 'DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="item<?php echo e($cnt == 0 ? ' active' : ''); ?>">
											<img src="<?php echo e($image->slide()); ?>" alt="<?php echo e($item->name); ?>">
										</div>

										<?php
											$cnt++;
										?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</div>

								<!-- Controls -->
								<a class="left carousel-control" href="#item-carousel" role="button" data-slide="prev">
									<span class="glyphicon glyphicon-chevron-left fa fa-arrow-left" aria-hidden="true"></span>
									<span class="sr-only">Previous</span>
								</a>
								
								<a class="right carousel-control" href="#item-carousel" role="button" data-slide="next">
									<span class="glyphicon glyphicon-chevron-right fa fa-arrow-right" aria-hidden="true"></span>
									<span class="sr-only">Next</span>
								</a>
							</div>
						<?php else: ?>
							<img src="<?php echo e(item_slide()); ?>" alt="" class="img-responsive">
						<?php endif; ?>

						<br>

						<h4>Description</h4>

						<p class="mtn-30"><?php echo nl2br(clean($item->description)); ?></p>
					</div>
				</div>
			</div>

			<div class="col-sm-4">
				<div class="card">
					<div class="card-body">
						<h3> <img src="<?php echo e(simba_coin()); ?>" alt="" class="size-30"> <?php echo e($item->price); ?> <small>Simba Coins</small></h3>
						<h4 class="mb-0 mtn-25"><?php echo e($item->name); ?></h4>
					</div>
				</div>

				<div class="card">
					<div class="card-body">
						

						<div class="row">
							<div class="col-xs-3">
								<img src="<?php echo e($item->donor ? $item->donor->profile_thumbnail() : profile_thumbnail()); ?>" alt="<?php echo e($item->donor ? $item->donor->name : ''); ?>" class="img-responsive img-circle">
							</div>

							<div class="col-xs-9">
								<p class="mt-10 mb-0">
									<?php echo e($item->donor ? characters($item->donor->name, 30) : ''); ?> <br>
									<a href="<?php echo e(route('user.show', ['username' => $item->donor->username])); ?>">View Profile</a>
								</p>
							</div>	
						</div>
						
					</div>
				</div>

				<div class="card">
					<div class="card-body">
						<h5>Donated Item Details</h5>
						<table class="" style="width:100%">
							<tr>
								<th>Posted</th>
								<td><?php echo e(simple_datetime($item->created_at)); ?></td>
							</tr>

							<tr>
								<th>Category</th>
								<td><?php echo e($item->category->name); ?></td>
							</tr>

							<tr>
								<th>Condition</th>
								<td><?php echo e(ucfirst(strtolower($item->condition))); ?></td>
							</tr>
						</table> 
						
						<?php if(auth()->check()): ?>
							<br>

							<?php if(!$item->bought && !$mine): ?>
								<a href="" data-toggle = "modal" data-target = "#report-item" class="btn btn-danger"> <i class="fa fa-bullhorn"></i> Report Item</a>
							<?php endif; ?>
						<?php else: ?>
							
						<?php endif; ?>
						
						
					</div>
				</div>
				
				<div class="">
					<?php if(!$item->bought): ?>
						<?php if(auth()->check()): ?>
							<?php if(!$mine): ?>
								<?php if($item->price > $user->coins): ?>
									<?php if($coin_request): ?>
										<a href="#" class="btn btn-primary btn-block">
											COIN PURCHASE REQUESTED,  <br> PLEASE WAIT FOR FEEDBACK FROM ADMIN
										</a>
									<?php else: ?>
										<a href="<?php echo e(route('user.purchase-coins')); ?>" class="btn btn-primary btn-block btn-lg" data-toggle="modal" data-target="#purchase-coins">
											<img src="<?php echo e(simba_coin()); ?>" alt="" class="size-30"> 
											PURCHASE EXTRA COINS
										</a>
									<?php endif; ?>
								<?php else: ?>
									<?php if($item->disputed): ?>
										<button class="btn btn-disabled btn-block btn-lg" disabled="">DISPUTED</button>
									<?php else: ?>
										<a href="<?php echo e(route('user.donated-item.purchase', ['slug' => $item->slug])); ?>" class="btn btn-primary btn-block btn-lg">PURCHASE</a>
									<?php endif; ?>


								<?php endif; ?>
							<?php else: ?>
								<?php if(!$item->disputed): ?>
									<div class="btn-group btn-group-justified">
										<a href="" data-toggle="modal" data-target="#edit-donated-item-<?php echo e($item->id); ?>" class="btn btn-info"><i class="fa fa-edit"></i> EDIT</a>

										<a href="" data-toggle="modal" data-target="#delete-donated-item-<?php echo e($item->id); ?>" class="btn btn-danger"><i class="fa fa-trash"></i> REMOVE FROM SHOP</a>
									</div> <br>

									<div class="btn-group btn-group-justified">
										<a href="" data-toggle="modal" data-target="#add-donated-item-image" class="btn btn-success"><i class="fa fa-plus"></i> ADD IMAGE</a>

										<a href="" data-toggle="modal" data-target="#delete-donated-item-image" class="btn btn-warning"><i class="fa fa-trash"></i> DELETE IMAGE</a>
									</div>
									

									<?php echo $__env->make('pages.user.modals.edit-donated-item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php echo $__env->make('pages.user.modals.delete-donated-item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php echo $__env->make('pages.user.modals.add-donated-item-image', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php echo $__env->make('pages.user.modals.delete-donated-item-image', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								<?php else: ?>
									<button class="btn btn-disabled btn-block btn-lg" disabled="">DISPUTED</button>
								<?php endif; ?>
								
							<?php endif; ?>
							
						<?php else: ?>
							<a href="" class="btn btn-info btn-block btn-lg">LOG IN TO PURCHASE</a>
						<?php endif; ?>
					<?php else: ?>
						<?php if($item->disputed): ?>
							<button class="btn btn-disabled btn-block btn-lg" disabled="">DISPUTED</button>
						<?php else: ?>
							<button class="btn btn-disabled btn-block btn-lg" disabled="">PURCHASED</button>
						<?php endif; ?>
					<?php endif; ?>

				</div>
				
				
			</div>
		</div>
	</div>
		

<?php if(!auth()->check()): ?>
	<?php echo $__env->make('pages.user.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('pages.user.modals.buy-coins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php if(!$item->bought && !$mine): ?>
		<?php echo $__env->make('pages.user.modals.report-item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>