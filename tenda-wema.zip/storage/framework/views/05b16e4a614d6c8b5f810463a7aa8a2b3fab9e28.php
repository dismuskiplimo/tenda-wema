<?php if(Session::has('success')): ?>
	<div class="alert alert-success" role="alert">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php echo e(Session::get('success')); ?>.
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>


<?php if(Session::has('error')): ?>
	<div class="alert alert-danger" role="alert">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<strong>Error!</strong> <?php echo e(Session::get('error')); ?>.
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php if(count($errors)): ?>
	<div class="alert alert-danger" role="alert">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<strong>Error!</strong>
					
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>