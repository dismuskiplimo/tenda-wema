<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($title); ?></h1>
			<span><?php echo e(config('app.name')); ?> | <?php echo e($title); ?></span>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li class="active"><?php echo e($title); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-sm-offset-1">
				
			</div>
		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>