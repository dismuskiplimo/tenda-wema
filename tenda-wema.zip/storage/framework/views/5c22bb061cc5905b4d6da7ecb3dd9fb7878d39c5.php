<div class="modal fade" id="edit-donated-item-<?php echo e($item->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('user.donated-item.update', ['slug' => $item->slug])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Edit Domated Item</h4>
        </div>
        
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label for="item-name">Item Name</label>
                <input type="text" id="item-name" name="name" required="" class="form-control required" placeholder="item name" value="<?php echo e($item->name); ?>" />
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label for="type">Type</label>
                <select name="type" id="type" class="form-control required" required="">
                  <option value="">--Select Item Type --</option>
                  <option value="PRODUCT"<?php echo e($item->type == 'PRODUCT' ? ' selected' : ''); ?>>Product</option>
                  <option value="SERVICE"<?php echo e($item->type == 'SERVICE' ? ' selected' : ''); ?>>Service</option>
                </select>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label for="condition">Condition</label>
                <select name="condition" id="condition" class="form-control required" required="">
                  <option value="">--Select Item Condition --</option>
                  <option value="NEW"<?php echo e($item->condition == 'NEW' ? ' selected' : ''); ?>>New</option>
                  <option value="USED"<?php echo e($item->condition == 'USED' ? ' selected' : ''); ?>>Used</option>
                </select>
              </div>
            </div>

            <div class="col-sm-6">
              <div class="form-group">
                <label for="category_id">Category</label>
                <select name="category_id" id="category_id" class="form-control required" required="">
                  <option value=""> -- Select Item Category --</option>
                  <?php if(count($categories)): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"<?php echo e($item->category_id == $category->id ? ' selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                                    
                </select>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label for="item-description">Description</label>
                <textarea id="item-description" name="description" required="" class="form-control required" placeholder="item description" rows="6"><?php echo e($item->description); ?></textarea>
              </div>
            </div>

          </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>