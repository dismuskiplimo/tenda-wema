<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="">
	            <div class="row">
	            	<div class="col-sm-8">
	            		<div class="white-box">

	            			<h3 class="box-title"><?php echo e($title); ?></h3>
				            <p class="text-right">
				            	<?php if($donated_item->bought): ?>
				            		<?php if(!$donated_item->approved): ?>
										<a href="" data-toggle="modal" data-target="#purchase-approve-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-success"><i class="fa fa-check"></i> APPROVE PURCHASE</a>	
										<a href="" data-toggle="modal" data-target="#purchase-disapprove-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times"></i> DISAPPROVE PURCHASE</a>	

										<div class="text-left">
											<?php echo $__env->make('pages.admin.modals.approve-purchase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php echo $__env->make('pages.admin.modals.disapprove-purchase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
				            		<?php else: ?>
										
										
										<?php if(!$donated_item->received): ?>
											<a href="" data-toggle="modal" data-target="#item-receive-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-success"><i class="fa fa-check"></i> MARK AS RECEIVED</a>
											
											
											
										<?php endif; ?>

										<?php if(!$donated_item->disputed): ?>
											<a href="" data-toggle="modal" data-target="#item-dispute-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-warning"><i class="fa fa-bullhorn"></i> DISPUTE</a>

											
											
										<?php endif; ?>

										<div class="text-left">
											<?php echo $__env->make('pages.admin.modals.receive-item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php echo $__env->make('pages.admin.modals.dispute-item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
										
									<?php endif; ?>						
				            	<?php else: ?>
									<?php if(!$donated_item->deleted_at): ?>
										<a href="" data-toggle="modal" data-target="#item-remove-form-market-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> REMOVE FROM MARKET</a>

										<div class="text-left">
											<?php echo $__env->make('pages.admin.modals.remove-item-from-market', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
									<?php endif; ?>
									
				            	<?php endif; ?>
				            </p>

            				<hr>
							
							<?php if($item->images->count()): ?>
								<div id="item-carousel" class="carousel slide" data-ride="carousel">
									<!-- Indicators -->
									<ol class="carousel-indicators">
										

										<?php for($cnt = 0; $cnt < count($item->images); $cnt++): ?>
											
											<li data-target="#item-carousel" data-slide-to="<?php echo e($cnt); ?>" class="<?php echo e($cnt == 0 ? 'active' : ''); ?>"></li>
											
										<?php endfor; ?>
										
										
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner" role="listbox">
										<?php
											$cnt = 0;
										?>

										<?php $__currentLoopData = $item->images()->orderBy('created_at', 'DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="item<?php echo e($cnt == 0 ? ' active' : ''); ?>">
												<img src="<?php echo e($image->slide()); ?>" alt="<?php echo e($item->name); ?>">
											</div>

											<?php
												$cnt++;
											?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</div>

									<!-- Controls -->
									<a class="left carousel-control" href="#item-carousel" role="button" data-slide="prev">
										<span class="glyphicon glyphicon-chevron-left fa fa-arrow-left" aria-hidden="true"></span>
										<span class="sr-only">Previous</span>
									</a>
									
									<a class="right carousel-control" href="#item-carousel" role="button" data-slide="next">
										<span class="glyphicon glyphicon-chevron-right fa fa-arrow-right" aria-hidden="true"></span>
										<span class="sr-only">Next</span>
									</a>
								</div>
							<?php else: ?>
								<img src="<?php echo e(item_slide()); ?>" alt="" class="img-responsive">
							<?php endif; ?>

							<br>

							<h4>Description</h4>

							<p class=""><?php echo nl2br(clean($item->description)); ?></p>
							
						</div>
	            	</div>

	            	<div class="col-sm-4">
	            		<div class="white-box">
							<h4 class="box-title">
								Status
							</h4>

							<h3><?php echo e($item->status()); ?></h3>
						</div>

	            		<div class="white-box">
							<div class="">
								<h3> <img src="<?php echo e(simba_coin()); ?>" alt="" class="size-30"> <?php echo e($item->price); ?> <small>Simba Coins</small></h3>
								<h4><?php echo e($item->name); ?></h4>
							</div>
						</div>

						<div class="white-box">
							<div class="box-title">SELLER</div>
							<hr>

							<div class="">
								

								<div class="row">
									<div class="col-sm-3">
										<img src="<?php echo e($item->donor ? $item->donor->profile_thumbnail() : profile_thumbnail()); ?>" alt="<?php echo e($item->donor ? $item->donor->name : ''); ?>" class="img-responsive img-circle">
									</div>

									<div class="col-sm-9">
										<p class="mt-10 mb-0">
											<?php echo e($item->donor ? characters($item->donor->name, 30) : ''); ?> <br>
											<a href="<?php echo e(route('admin.user', ['id' => $item->donor->id])); ?>">View Profile</a>
										</p>
									</div>	
								</div>
								
							</div>
						</div>

						<?php if($item->bought): ?>
							<div class="white-box">
								<div class="box-title">BUYER</div>
								<hr>

								<div class="">
									

									<div class="row">
										<div class="col-sm-3">
											<img src="<?php echo e($item->buyer ? $item->buyer->profile_thumbnail() : profile_thumbnail()); ?>" alt="<?php echo e($item->buyer ? $item->buyer->name : ''); ?>" class="img-responsive img-circle">
										</div>

										<div class="col-sm-9">
											<p class="mt-10 mb-0">
												<?php echo e($item->buyer ? characters($item->buyer->name, 30) : ''); ?> <br>
												<a href="<?php echo e(route('admin.user', ['id' => $item->buyer->id])); ?>">View Profile</a>
											</p>
										</div>	
									</div>
									
								</div>
							</div>
						<?php endif; ?>

						<div class="white-box">
							<div class="box-title">Donated Item Details</div>
							<div class="">
								
								<table class="" style="width:100%">
									<tr>
										<th>Posted</th>
										<td><?php echo e(simple_datetime($item->created_at)); ?></td>
									</tr>

									<tr>
										<th>Category</th>
										<td><?php echo e($item->category->name); ?></td>
									</tr>

									<tr>
										<th>Condition</th>
										<td><?php echo e(ucfirst(strtolower($item->condition))); ?></td>
									</tr>
								</table>
								
								
							</div>
						</div>

						<a href="<?php echo e(route('admin.message.new', ['id' => $item->donor->id])); ?>" class="btn btn-block btn-info btn-lg mb-10">
							<i class="fa fa-send"></i> MESSAGE SELLER
						</a>

						<?php if($item->bought): ?>

						<a href="<?php echo e(route('admin.message.new', ['id' => $item->buyer->id])); ?>" class="btn btn-block btn-primary btn-lg">
							<i class="fa fa-send"></i> MESSAGE BUYER
						</a>

						<?php endif; ?>


	            	</div>
	            </div>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>