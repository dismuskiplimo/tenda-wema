<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($user->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Users</li>
				<li class="active"><?php echo e($user->name); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row my-50">
			<div class="col-sm-3">
				<?php echo $__env->make('includes.user.profile-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>

			<div class="col-sm-9">
				<h4>TIMELINE</h4>
				<?php if($timeline->total()): ?>
					<?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card">
							<div class="card-body">
								<?php if($event->type == 'user.register'): ?>
									<strong><?php echo e($event->message); ?></strong>
								<?php elseif($event->type == 'item.donated'): ?>
									<div class="row">
										<?php
											$item = $event->donated_item;

											$thumbnail = item_thumbnail();

											if($item->images){
												$donated_item_image = $item->images()->first();

												if($donated_item_image){
													$thumbnail 		= $donated_item_image->thumbnail();
												}
									
											}
										?>

										<div class="col-sm-4">
											<a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>">
												<img src="<?php echo e($thumbnail); ?>" alt="<?php echo e($item->name); ?>" class="img-responsive">	
											</a>	
											
										</div>

										<div class="col-sm-8">
											<h4>Donated Item</h4>
											<h5 class="mt-10 mb-0">
												<a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>"><?php echo e(characters($item->name, 20)); ?></a>	
											</h5>

											<small class="text-muted"><?php echo e($item->category ? $item->category->name : ''); ?></small>
										</div>
									</div>
								<?php elseif($event->type == 'social_level.upgraded'): ?>
									<p>
										<img src="<?php echo e(social_badge($event->extra)); ?>" alt="<?php echo e($event->extra); ?> badge" class="size-20 mr-10p">
										<?php echo e($event->message); ?>

									</p>
								<?php endif; ?>

								<p class="text-right mb-0">
									<small class="text-muted">
										<?php echo e(simple_datetime($event->created_at)); ?>

									</small>
								</p>

								
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php echo e($timeline->links()); ?>

				<?php else: ?>
					<p class="text-muted">No activity</p>
				<?php endif; ?>
			</div>
		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>