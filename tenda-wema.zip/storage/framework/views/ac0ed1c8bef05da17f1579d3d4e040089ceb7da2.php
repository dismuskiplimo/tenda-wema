<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?> (<?php echo e(number_format($contacts->total())); ?>)</h3>

	            <?php if($contacts->total()): ?>
		            <table class="table">
		            	<thead>
		            		<tr>
		            			<th>Name</th>
		            			<th>Subject</th>
		            			<th>Email</th>
		            			<th>Phone</th>
		            			<th>Message</th>
		            			
		            			<th></th>
		            		</tr>

		            	</thead>

		            	<tbody>
		            		
		            		<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr<?php echo $contact->read ? '' : ' class="bg-muted"'; ?>>
									<td><?php echo e($contact->name); ?></td>
									<td><?php echo e($contact->subject); ?></td>
									<td><?php echo e($contact->email); ?></td>
									<td><?php echo e($contact->phone); ?></td>
									<td><?php echo e(characters($contact->message, 20)); ?></td>
									
									<td><a class = "btn btn-xs" href="<?php echo e(route('admin.contact-form', ['id' => $contact->id])); ?>"><i class="fa fa-eye"></i></a></td>
								</tr>
		            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            		
		            	</tbody>
		            </table>
		            	<?php echo e($contacts->links()); ?>

		            <?php else: ?>
						<p>No messages from contact form</p>
		            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>