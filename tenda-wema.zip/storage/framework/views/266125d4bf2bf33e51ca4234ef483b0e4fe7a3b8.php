<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <div class="row">
	            	<div class="col-sm-12">
	            		<h3 class="box-title">
	            			<?php echo e($title); ?>


	            			<a href="<?php echo e(route('admin.support-causes')); ?>" class="btn btn-sm btn-info pull-right"><i class="fa fa-arrow-left"></i> BACK</a>
	            		</h3>

	            		<?php if($donation->received == 0 && $donation->dismissed == 0): ?>
							<p>
								<a href="" data-toggle="modal" data-target="#receive-donation-request-<?php echo e($donation->id); ?>" class="btn btn-sm btn-success"><i class="fa fa-check"></i> MARK AS RECEIVED</a>

								<a href="" data-toggle="modal" data-target="#dismiss-donation-request-<?php echo e($donation->id); ?>" class="btn btn-sm btn-danger"><i class="fa fa-times"></i> DISMISS DONATION REQUEST</a>	
							</p>

							<?php echo $__env->make('pages.admin.modals.receive-donation-request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<?php echo $__env->make('pages.admin.modals.dismiss-donation-request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							
	            		<?php endif; ?>

	            		
	            	</div>

	            </div>
	            
 
	            <table class="table table-striped">
	            	<tr>
	            		<th>Name</th>
	            		<td><?php echo e($donation->fname . ' ' . $donation->lname); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Organization</th>
	            		<td><?php echo e($donation->organization); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Amount</th>
	            		<td>KES <?php echo e(number_format($donation->amount)); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Donating as</th>
	            		<td><?php echo e($donation->donating_as); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Preferred Method</th>
	            		<td><?php echo e($donation->method); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Country</th>
	            		<td><?php echo e($donation->country); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Phone</th>
	            		<td><?php echo e($donation->phone); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Email</th>
	            		<td><?php echo e($donation->email); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Status</th>
	            		<td><?php echo e($donation->status()); ?></td>
	            	</tr>

	            	<?php if($donation->approved): ?>
						<tr>
		            		<th>Received By</th>
		            		<td><?php echo e($donation->receiver->name); ?></td>
		            	</tr>

						<tr>
		            		<th>Date Received</th>
		            		<td><?php echo e(simple_datetime($donation->received_at)); ?></td>
		            	</tr>

		            	
	            	<?php endif; ?>

	            	<?php if($donation->dismissed): ?>
						<tr>
		            		<th>Dismissed By</th>
		            		<td><?php echo e($donation->dismisser->name); ?></td>
		            	</tr>

						<tr>
		            		<th>Date Dismissed</th>
		            		<td><?php echo e(simple_datetime($donation->dismissed_at)); ?></td>
		            	</tr>

		            	<tr>
		            		<th>Reason Dismissed</th>
		            		<td><?php echo e($donation->dismissed_reason); ?></td>
		            	</tr>
	            	<?php endif; ?>
	            	
	            </table>
     
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>