<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?>  (<?php echo e(number_format($escrow->total())); ?>)</h3>

	            <?php if(count($escrow)): ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Date</th>
								<th>Amount (Simba Coins)</th>
								<th>Settled</th>
								<th>User</th>
								<th>Donated Item</th>
								
								
								
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $escrow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($r->created_at); ?></td>
									<td><?php echo e(number_format($r->amount)); ?></td>
									<td><?php echo e($r->released ? 'YES' : 'NO'); ?></td>
									<td><a href="<?php echo e(route('admin.user', ['id' => $r->user->id])); ?>"><?php echo e($r->user->name); ?></a></td>
									<td><a href="<?php echo e(route('admin.donated-item', ['id' => $r->donated_item->id])); ?>"> <?php echo e($r->donated_item->name); ?></a></td>
																	
									
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($escrow->links()); ?>

	            <?php else: ?>
					No <?php echo e($title); ?>

	            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>