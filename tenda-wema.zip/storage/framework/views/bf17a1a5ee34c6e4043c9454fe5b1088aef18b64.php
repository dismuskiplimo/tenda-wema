<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <div class="row">
	            	<div class="col-sm-12">
	            		<h3 class="box-title">
	            			<?php echo e($title); ?>


	            			<a href="<?php echo e(route('admin.deeds', ['type' => 'pending-approval'])); ?>" class="btn btn-xs pull-right btn-info"><i class="fa fa-arrow-left"></i> BACK</a>
	            		</h3>


	            	</div>
	            </div>
	            

	            <p class="text-right">
	            	<?php if($deed->approved): ?>
						<a href=""  data-toggle = "modal" data-target = "#deed-disapprove-<?php echo e($deed->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times" title="Disapprove Deed"></i> Disapprove Deed</a>

						<?php echo $__env->make('pages.admin.modals.disapprove-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php else: ?>
						<?php if($deed->disapproved): ?>
							<a href="" data-toggle = "modal" data-target = "#deed-approve-<?php echo e($deed->id); ?>"  class="btn btn-xs btn-success"><i class="fa fa-check" title="Approve Deed"></i> Approve Deed</a>
						<?php else: ?>
							<a href="" data-toggle = "modal" data-target = "#deed-approve-<?php echo e($deed->id); ?>"  class="btn btn-xs btn-success"><i class="fa fa-check" title="Approve Deed"></i> Approve Deed</a>

							<a href="" data-toggle = "modal" data-target = "#deed-disapprove-<?php echo e($deed->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times" title="Disapprove Deed"></i> Disapprove Deed</a>

							<?php echo $__env->make('pages.admin.modals.disapprove-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php endif; ?>

						<?php echo $__env->make('pages.admin.modals.approve-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						

					<?php endif; ?>
	            </p>

	            <hr>


	            <div class="row">
					<div class="col-sm-6 border-right">
						<h4 class="text-muted">GOOD DEED</h4> 
						<h5> <?php echo e($deed->name); ?> <br>  <br>
							
							<small class="text-muted"><?php echo e(simple_datetime($deed->created_at)); ?></small>
						</h5>

						<hr>

						<h4 class="mb-0 text-muted">LOCATION</h4>
						<p><?php echo e($deed->location); ?></p>

						<hr>

						<h4 class="mb-0 text-muted">DESCRIPTION</h4>
						<?php echo clean(nl2br($deed->description)); ?>


						<hr>
						
						<h4 class="mb-0 text-muted">CONTACTS</h4>
						<?php echo clean(nl2br($deed->contacts)); ?>

						
					</div>

					<div class="col-sm-6">
						<?php
							if($deed->disapproved){
								$color = 'red';
								$text = 'NOT APPROVED';
							}else{
								$color = $deed->approved ? 'green' : 'orange';
								$text = $deed->approved ? 'APPROVED' : 'PENDING APPROVAL';
							}
							

							

						?>

						<h4 class="mb-10">DONE BY <span class="pull-right" style ="color:<?php echo e($color); ?>"><?php echo e($text); ?></span> </h4>
						<p>
							<a href="<?php echo e(route('admin.user', ['id' => $deed->user->id])); ?>">
								<img src="<?php echo e($deed->user ? $deed->user->profile_thumbnail() : ''); ?>" alt="<?php echo e($deed->user ? $deed->user->name : ''); ?>" class="size-30 mr-10 img-circle"> 

								<i class="mt-10">
									<?php echo e($deed->user ? $deed->user->name : ''); ?>	
								</i>
								
							</a>
						</p>
						
						<h4 class="mb-5">EVIDENCE (<?php echo e(count($deed->images)); ?>)</h4>
						<?php if(count($deed->images)): ?>
							<div class="row">
								<?php
									$count = 0;
								?>

								<?php $__currentLoopData = $deed->images()->orderBy('created_at', 'DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
										$count++;
									?>
									<div class="col-sm-4">
										<a data-fancybox="gallery" href="<?php echo e($image->image()); ?>">
											<img src="<?php echo e($image->thumbnail()); ?>" alt="<?php echo e($image->user ? $image->user->name : ''); ?>" class="img-responsive img-rounded">
										</a>
									</div>

									<?php if($count % 3 == 0): ?>
										</div>
										<div class="row mb-20">
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							</div>
							
						<?php else: ?>
							<p class="text-muted mb-0">No evidence attached</p>
						<?php endif; ?>
					</div>
				</div>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>