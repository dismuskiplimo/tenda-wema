		<!-- Header ============================================= -->
		<header id="header" class="full-header">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="<?php echo e(route('homepage')); ?>" class="standard-logo" data-dark-logo="<?php echo e(custom_asset('images/logo.png')); ?>">
							<img src="<?php echo e(custom_asset('images/logo.png')); ?>" alt="Canvas Logo">
						</a>

						<a href="<?php echo e(route('homepage')); ?>" class="retina-logo" data-dark-logo="<?php echo e(custom_asset('images/logo.png')); ?>">
							<img src="<?php echo e(custom_asset('images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?> Logo">
						</a>
					</div><!-- #logo end -->

					<?php if(auth()->check()): ?>
						<div id="top-account" class="dropdown">
							<a href="#" class="btn btn-default dropdown-toggle mtn-3 mbn-5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img src="<?php echo e(auth()->user()->profile_picture()); ?>" alt="" class="img-circle size-25 mr-10">
								 <span class="mt-8">
								 	<small><?php echo e(auth()->user()->fname); ?> </small>

								 	<i class="icon-angle-down"></i>
								 </span>
								 
								</a>
							<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
								<?php if(!auth()->user()->is_admin()): ?>
								<li><a href="<?php echo e(route('user.donated-items.show', ['username' => auth()->user()->username])); ?>">My Donated Items</a></li>
								<li><a href="<?php echo e(route('user.good-deeds.show', ['username' => auth()->user()->username])); ?>">My Good Deeds</a></li>
								<li><a href="<?php echo e(route('user.show', ['username' => auth()->user()->username])); ?>">My Profile</a></li>
								<li><a href="<?php echo e(route('user.items-bought.show', ['username' => auth()->user()->username])); ?>">Items Bought</a></li>
								<li><a href="<?php echo e(route('user.settings')); ?>">Settings</a></li>
								<li role="separator" class="divider"></li>
								<li><a href="<?php echo e(route('user.message', ['username' => auth()->user()->username, 'support' => 'true'])); ?>">Contact Admin</a></li>
								<li role="separator" class="divider"></li>
								<?php else: ?>
									<li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
								<?php endif; ?>


								<li><a href="<?php echo e(route('auth.logout')); ?>">Logout <i class="icon-signout"></i></a></li>
							</ul>
						</div>
					<?php endif; ?>

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">
						
						<ul>
							<li>
								<a href="<?php echo e(route('homepage')); ?>">
									<small>Home</small>
								</a>
							</li>

							<li>
								<a href="<?php echo e(route('donate-item')); ?>">
									<small>Donate</small>
								</a>
							</li>

							

							<li>
								<a href="<?php echo e(route('community-shop')); ?>">
									<small>Community Shop</small>
								</a>
							</li>

							<li>
								<a href="<?php echo e(route('good-deeds')); ?>">
									<small>Good Deeds</small>
								</a>
							</li>

							<?php if(!auth()->check()): ?>
								<li>
									<a href="<?php echo e(route('auth.signup')); ?>">
										<small>Sign Up</small>
									</a>
								</li>

								<li>
									<a href="<?php echo e(route('auth.login')); ?>">
										<small>Login</small>
									</a>
								</li>

							<?php elseif(!auth()->user()->is_admin()): ?>
								<li>
									<a href="<?php echo e(route('user.balance')); ?>" title="Simba Coins">
										<img src="<?php echo e(simba_coin()); ?>" alt="Simba Coin" class="size-20">
										<?php echo e(number_format(auth()->user()->coins)); ?>

									</a>
								</li>

								<li>
									<a href="<?php echo e(route('user.messages')); ?>" class="user-messages" title="messages">
										<i class="fa fa-envelope h-15 mt-7"></i>
										<small class="badge mtn-20 mrn-10"><?php echo e(auth()->user()->message_notifications()->where('read',0)->count() ? : ''); ?></small>
									</a>
								</li>

								<li>
									<a href="<?php echo e(route('user.notifications')); ?>" class="user-notifications" title="notifications">
										<i class="fa fa-globe h-15 mt-7"></i>
										<small class="badge mtn-20 mrn-10"><?php echo e(auth()->user()->notifications()->where('read',0)->count() ? : ''); ?></small>
									</a>
								</li>
							<?php endif; ?>

							

						</ul>

						

						

						<!-- Top Search
						============================================= -->

						<div id="top-search">
							<a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
							<form action="search.html" method="get">
								<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
							</form>
						</div><!-- #top-search end -->

					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->