<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?> (<?php echo e(number_format($users->total())); ?>)</h3>

	            <?php if(count($users)): ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Name</th>
								<th>Username</th>
								<th>Email</th>
								<th>Coins</th>
								<th>Email Confirmed</th>
								<th>Last Seen</th>
								<th></th>
								
								
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->username); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><?php echo e(number_format($user->coins)); ?></td>
									<td><?php echo e($user->email_confirmed ? 'YES' : 'NO'); ?></td>
									<td><?php echo e(simple_datetime($user->last_seen)); ?></td>
									<td><a href="<?php echo e(route('admin.user', ['id' => $user->id])); ?>" class=""><i class="fa fa-eye"></i></a></td>
									
									
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($users->links()); ?>

	            <?php else: ?>
					No <?php echo e($title); ?>

	            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>