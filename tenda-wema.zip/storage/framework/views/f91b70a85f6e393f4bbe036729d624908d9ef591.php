<?php $__env->startSection('content'); ?>
		<!-- Page Title
		============================================= -->
		<section id="page-title">

			<div class="container clearfix">
				<h1>Community Shop</h1>
				<span>Purchase Donated Items</span>
				<ol class="breadcrumb">
					<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
					<li class="active">Shop</li>
				</ol>
			</div>

		</section><!-- #page-title end -->

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Shop
					============================================= -->
					<div id="shop" class="shop grid-container clearfix" data-layout="fitRows">

						<?php if($donated_items->total()): ?>
							<?php $__currentLoopData = $donated_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									$banner = item_banner();

									if($item->images){
										$donated_item_image = $item->images()->first();

										if($donated_item_image){
											$banner 		= $donated_item_image->banner();
										}
										
									}
								?>

								<div class="product clearfix">
									<div class="product-image"   style="box-shadow: 0px 0px 12px #ccc">
										<a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>">
											<img src="<?php echo e($banner); ?>" alt="<?php echo e($item->name); ?>">
										</a>
										
									</div>
									<div class="product-desc"  style="box-shadow: 0px 0px 12px #ccc">
										<div style="padding-left:10px">
												<div class="product-title mb-0"><h3><a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>"><?php echo e(characters($item->name, 20)); ?></a></h3></div>
											
											<small class="text-muted"><?php echo e($item->category ? $item->category->name : ''); ?></small>
											
											<div class="product-price mt-5">
												
												<ins>
													<img src="<?php echo e(custom_asset('images/simba-coin.png')); ?>" alt="" class="size-25 mtn-3"> 
														<?php echo e($item->price); ?> <small class="lato">Simba Coins</small>
												</ins>
											</div>	
										</div>
										
										
									</div>
								</div>		
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h3 class="">No Items Available</h3>
						<?php endif; ?>

						

					</div><!-- #shop end -->

				</div>

			</div>

		</section><!-- #content end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>