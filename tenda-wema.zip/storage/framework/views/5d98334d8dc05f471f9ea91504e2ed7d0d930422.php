<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <div class="row">
	            	<div class="col-sm-12">
	            		<h3 class="box-title">
	            			<?php echo e($title); ?>


	            			<a href="<?php echo e(route('admin.contact-forms')); ?>" class="btn btn-sm btn-info pull-right"><i class="fa fa-arrow-left"></i> BACK</a>
	            		</h3>

	            			            		
	            	</div>

	            </div>
	            
 
	            <table class="table table-striped">
	            	<tr>
	            		<th>Date</th>
	            		<td><?php echo e(simple_datetime($contact->created_at)); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Name</th>
	            		<td><?php echo e($contact->name); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Email</th>
	            		<td><?php echo e($contact->email); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Phone</th>
	            		<td><?php echo e($contact->phone); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Subject</th>
	            		<td><?php echo e($contact->subject); ?></td>
	            	</tr>

	            	<tr>
	            		<th>Message</th>
	            		<td><?php echo clean(nl2br($contact->message)); ?></td>
	            	</tr>

	            	
	            	
	            </table>
     
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>