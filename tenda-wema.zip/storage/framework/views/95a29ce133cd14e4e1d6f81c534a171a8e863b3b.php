<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">

	            

	            <?php if(!$report->approved && !$report->dismissed): ?>
					<p class="text-right">
						<a href="" data-toggle="modal" data-target="#approve-misconduct-<?php echo e($report->id); ?>" class="btn btn-xs btn-success"><i class="fa fa-check"></i> Confirm Misconduct</a>

						<a href="" data-toggle="modal" data-target="#dismiss-misconduct-<?php echo e($report->id); ?>" class="btn btn-xs btn-warning"><i class="fa fa-times"></i> Dismiss Misconduct</a>
					</p>
					
					<?php echo $__env->make('pages.admin.modals.approve-misconduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php echo $__env->make('pages.admin.modals.dismiss-misconduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<hr>
	            <?php endif; ?>

	            <div class="row">
	            	<div class="col-sm-12">
            			<h3 class="box-title full-width">
		            		<?php echo e($title); ?>


		            		<a href="<?php echo e(route('admin.users.reported', 'all')); ?>" class="btn btn-xs btn-info pull-right"><i class="fa fa-arrow-left"></i> BACK</a>
	            		</h3>
	            	</div>
	            </div>
	            
				<div class="row">
					<div class="col-sm-12">
						<table class="table table-striped">
							
							<tbody>

								<tr>
									<th>Status</th>
									<td><?php echo e($report->status()); ?></td>
								</tr>

								<tr>
									<th>Date</th>
									<td><?php echo e(simple_datetime($report->created_at)); ?></td>
								</tr>

								<tr>
									<th>Victim</th>
									<td><a href="<?php echo e(route('admin.user', ['id' => $report->user->id])); ?>"><?php echo e($report->user->name); ?></a></td>
								</tr>

								<tr>
									<th>Reported By</th>
									<td><a href="<?php echo e(route('admin.user', ['id' => $report->reporter->id])); ?>"><?php echo e($report->reporter->name); ?></a></td>
								</tr>

								<tr>
									<th>Reason</th>
									<td><?php echo e($report->report_type->description); ?></td>
								</tr>

								<tr>
									<th>Details</th>
									<td><?php echo e($report->description); ?></td>
								</tr>

								<?php if($report->approved): ?>
									<tr>
										<th>Approved By</th>
										<td>
											<a href="<?php echo e(route('admin.user', ['id' => $report->approver->id])); ?>"><?php echo e($report->approver->name); ?></a>

										</td>
									</tr>

									<tr>
										<th>Approved At</th>
										<td><?php echo e(simple_datetime($report->approved_at)); ?></td>
									</tr>
								<?php endif; ?>

								<?php if($report->dismissed): ?>
									<tr>
										<th>Dismissed By</th>

										<td>
											<a href="<?php echo e(route('admin.user', ['id' => $report->dismisser->id])); ?>"><?php echo e($report->dismisser->name); ?></a>
											
										</td>
									</tr>
									

									<tr>
										<th>Dismissed At</th>
										<td><?php echo e(simple_datetime($report->dismissed_at)); ?></td>
									</tr>

									<tr>
										<th>Reason to dismiss</th>
										<td><?php echo e($report->dismissed_reason); ?></td>
									</tr>
								<?php endif; ?>

								<?php if($report->section == 'user'): ?>
									<tr>
										<th>View Reported User</th>
										<td><a target="_blank" href="<?php echo e(route('admin.user', ['id' => $report->user_model->id])); ?>"><?php echo e($report->user_model->name); ?></a></td>
									</tr>

								<?php elseif($report->section == 'item'): ?>
									<tr>
										<th>View Reported Item</th>
										<td><a target="_blank" href="<?php echo e(route('admin.donated-item', ['id' => $report->item_model->id])); ?>"><?php echo e($report->item_model->name); ?></a></td>
									</tr>
								<?php elseif($report->section == 'post'): ?>
									<tr>
										<th>View Reported Post</th>
										<td>
											<a target="_blank" href="<?php echo e(route('post', ['slug' => $report->post_model->slug ])); ?>">
												
												<strong><?php echo e($report->post_model->title); ?></strong> <br>

												<?php echo clean(nl2br($report->post_model->content)); ?>

											</a>
										</td>
									</tr>
								<?php elseif($report->section == 'comment'): ?>
									<tr>
										<th>View Reported Comment</th>
										<td>
											<a href="<?php echo e(route('post', ['slug' => $report->comment_model->post->slug])); ?>#comment-<?php echo e($report->comment_model->id); ?>">
													<?php echo clean(nl2br($report->comment_model->content)); ?>

											</a>
										</td>
									</tr>
								<?php endif; ?>

								
								
							</tbody>
						</table>
						
					</div>
					
				</div>
	        </div>
	        
	    </div>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>