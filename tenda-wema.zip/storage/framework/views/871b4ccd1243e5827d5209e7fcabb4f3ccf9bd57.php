<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title full-width">
	            	<?php echo e($title); ?>

	            </h3>
	
				<?php if($transactions->total()): ?>
					<div class="row">
						<div class="col-sm-12">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>Date</th>
										<th>Transaction Code</th>
										<th>Phone Number</th>
										<th>Amount</th>
										<th>Coins</th>
										<th>Transaction Date</th>
										<th>User</th>
										
									</tr>
								</thead>

								<tbody>
									<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<tr>
											<td><?php echo e(simple_datetime($transaction->created_at)); ?></td>
											<td><?php echo e($transaction->MpesaReceiptNumber); ?></td>
											<td><?php echo e($transaction->PhoneNumber); ?></td>
											<td><?php echo e($transaction->Amount); ?></td>
											<td><?php echo e(number_format($transaction->coins)); ?> Simba Coins</td>
											<td><?php echo e(mpesa_date($transaction->TransactionDate)); ?></td>
											<td><a href="<?php echo e(route('admin.user', ['id' => $transaction->user->id])); ?>"><?php echo e($transaction->user->name); ?></a></td>
												
										</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
							
						</div>
						
					</div>

					<?php echo e($transactions->links()); ?>

					
				<?php else: ?>
					<i>No mpesa transactions</i>
				<?php endif; ?>
	            
	        </div>
	        
	    </div>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>