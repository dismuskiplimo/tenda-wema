<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e(characters($title, 20)); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li><a href="<?php echo e(route('posts')); ?>">Posts</a></li>
				<li class="active"><?php echo e(characters($title, 20)); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row py-50">
			<div class="col-sm-10 col-sm-offset-1">
				<div class="panel panel-info">
					<div class="panel-body">
					    <div class="row">
					    	<div class="col-sm-9">
					    		<h4 class="nobottommargin">
									<a href="<?php echo e(route('user.show', ['username' => $post->user->username])); ?>">
										<img src="<?php echo e($post->user->thumbnail()); ?>" alt="" class="size-50 mr-10 pull-left"> 
										<?php echo e($post->user->name); ?> <br>
										<small class="text-muted">
											 <?php echo e(simple_datetime($post->created_at)); ?>

										</small>
										
									</a>
								</h4>
					    	</div>

					    	<div class="col-sm-3 text-right">
					    		<?php if(auth()->check() && !auth()->user()->is_admin()): ?>
									<?php if(!$mine): ?>
										<a href="" data-toggle="modal" data-target="#report-post-<?php echo e($post->id); ?>" title="report post" class="btn btn-danger"><i class="fa fa-bullhorn"></i></a>

										<?php echo $__env->make('pages.user.modals.report-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php else: ?>
										<a href="" data-toggle="modal" data-target="#edit-post-<?php echo e($post->id); ?>" title="edit post" class="btn btn-warning"><i class="fa fa-edit"></i></a>

										<a href="" data-toggle="modal" data-target="#delete-post-<?php echo e($post->id); ?>" title="delete post" class="btn btn-danger"><i class="fa fa-trash"></i></a>

										<?php echo $__env->make('pages.user.modals.edit-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										<?php echo $__env->make('pages.user.modals.delete-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php endif; ?>
									
								<?php else: ?>
									<a href="" data-toggle="modal" data-target="#login-modal" title="login to comment" class="btn text-success btn-xs"><i class="fa fa-login"></i></a>
								<?php endif; ?>
					    	</div>
					    </div>

					    <hr>

					    <h3 class="">
					    	<a href="<?php echo e(route('post', ['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a>
					    </h3>
					    
					    
					    	<?php echo clean(nl2br($post->content)); ?>

					    	
					    
						
						<p class="text-muted nobottommargin text-right">
							<small>
								Posted by 
								<a href="<?php echo e(route('user.show', ['username' => $post->user->username])); ?>">
									
									<?php echo e($post->user->name); ?>

								</a> | <?php echo e(simple_datetime($post->created_at)); ?> | Comments(<?php echo e(number_format(count($comments))); ?>)
							</small>
						</p>

					</div>
				</div>

				<h4 class="nobottommargin">Comments(<?php echo e(number_format(count($comments))); ?>)</h4>

				

				<?php if(count($post->comments)): ?>
					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="panel" id = "comment-<?php echo e($comment->id); ?>">
							<div class="panel-body">
								<div class="row">
									<div class="col-sm-10">
										<p class="nobottommargin">
											<a href="<?php echo e(route('user.show', ['username' => $comment->user->username])); ?>">
												<img src="<?php echo e($comment->user->thumbnail()); ?>" alt="" class="size-20 mtn-5 mr-10"> 
												<?php echo e($comment->user->name); ?>,
												<small class="text-muted">
													 <?php echo e(simple_datetime($comment->created_at)); ?>

												</small>
												
											</a>
										</p>
									</div>
									
									<div class="col-sm-2 text-right">
										<?php if(auth()->check() && !auth()->user()->is_admin()): ?>
											<?php if(auth()->user()->id != $comment->user_id): ?>
												<a href="" data-toggle="modal" data-target="#report-comment-<?php echo e($comment->id); ?>" title="report comment" class="btn text-danger btn-xs"><i class="fa fa-bullhorn"></i></a>

												<?php echo $__env->make('pages.user.modals.report-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php else: ?>
												<a href="" data-toggle="modal" data-target="#edit-comment-<?php echo e($comment->id); ?>" title="edit comment" class="btn text-warning btn-xs"><i class="fa fa-edit"></i></a>

												<a href="" data-toggle="modal" data-target="#delete-comment-<?php echo e($comment->id); ?>" title="delete comment" class="btn text-danger btn-xs"><i class="fa fa-trash"></i></a>

												<?php echo $__env->make('pages.user.modals.edit-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												<?php echo $__env->make('pages.user.modals.delete-comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php endif; ?>
											
										<?php endif; ?>
										
									</div>
								</div>
								

								<hr>

								<p class="nobottommargin"><?php echo e($comment->content); ?></p>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<p class="">No Comments for this post</p>
				<?php endif; ?>

				<?php if(auth()->check() && !auth()->user()->is_admin()): ?>
					<div class="panel panel-primary">
						<div class="panel-body">
							<form action="<?php echo e(route('post.comment', ['slug' => $post->slug])); ?>" method = "POST">
								<?php echo csrf_field(); ?>

								<div class="form-group">
									<label for="">Write Comment</label>
									<textarea name="content" id="" rows="4" class="form-control" required=""></textarea>
								</div>

								<button class="button button-green button-3d nobottommargin pull-right" type="submit"><i class="fa fa-comment"></i> COMMENT</button>
							</form>
						</div>
					</div>

				<?php else: ?>
					<p>
						<a href="" data-toggle="modal" data-target="#login-modal" title="login to comment" class="btn text-success btn-xs"><i class="fa fa-login"></i> Login To Comment</a>
					</p>
					
				<?php endif; ?>

			</div>
		</div>
	</div>

	<?php if(!auth()->check()): ?>
		<?php echo $__env->make('pages.user.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php else: ?>
		<?php if(!$mine): ?>
			
		<?php endif; ?>
	<?php endif; ?>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>