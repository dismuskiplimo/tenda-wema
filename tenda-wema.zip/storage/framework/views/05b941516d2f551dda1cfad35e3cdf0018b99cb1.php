<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row mt-50">
			<div class="col-sm-4">
				
					<div class="card">
						<div class="card-body h-400 overflow-y-scroll">
							<?php if(count($conversations)): ?>
								<b>Conversations(<?php echo e(number_format(count($conversations))); ?>)</b> <br> <hr>
								
								<?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(route('user.conversation', ['id' => $conversation->id])); ?>" title="View Conversation">
										<div class="panel  <?php echo e($conversation->id == $current_conversation->id ? 'panel-info' : 'panel-default'); ?>">
											<div class="panel-body">
												<div class="row">		
													<?php if($conversation->support): ?>
														<div class="col-xs-3">
															<img src="<?php echo e(simba_coin()); ?>" alt="" class="img-responsive img-circle">
														</div>
														
														<div class="col-xs-9">
															<strong>Admin</strong> <br>
															<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
														</div>
													<?php else: ?>
														<?php if($conversation->from_id == $user->id): ?>
															<div class="col-xs-3">
																<img src="<?php echo e($conversation->to->thumbnail()); ?>" alt="" class="img-responsive img-circle">
															</div>
															<div class="col-xs-9">
																<strong><?php echo e($conversation->to->name); ?></strong><br>
																<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
															</div>
														<?php else: ?>
															<div class="col-xs-3">
																<img src="<?php echo e($conversation->from->thumbnail()); ?>" alt="" class="img-responsive img-circle">	
															</div>
															
															<div class="col-xs-9">
																<strong><?php echo e($conversation->from->name); ?></strong> <br>
																<small class="text-muted"><?php echo e($conversation->updated_at->diffForHumans()); ?></small>
															</div>
														<?php endif; ?>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							<?php else: ?>
								<p class="text-center mb-0">
									No Conversations
								</p>
							<?php endif; ?>
						</div>
					</div>
				
			</div>

			<div class="col-sm-8">
				<div class="card">
					<div class="card-body" style="padding-bottom: 0px">
						<h5 class="mb-0">
							<?php if($support_message): ?>
								<img src="<?php echo e(simba_coin()); ?>" alt="" class="size-35 mr-10 img-circle"> 
								<strong class="">Admin</strong>
							<?php else: ?>
								<a href="<?php echo e(route('user.show', ['username' => $to->username])); ?>">
									<img src="<?php echo e($to->thumbnail()); ?>" alt="" class="size-35 mr-10 img-circle"> <?php echo e($to->name); ?>	
								</a>
								
							<?php endif; ?>
						</h5>

						<hr>	
					</div>
					
					<div class="card-body conversation-box h-306"  style="padding-top: 0px">
						<div id="messages" style="min-height: 100%" class="front-messages">
							<?php if(count($messages)): ?>
								<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
									<?php if($message->from_admin): ?>
										<div class="msg-left msg">
									        <p class="mb-0">
									        	<small><b>Admin</b></small> <br>
									        	<small><?php echo e($message->message); ?></small> <br>
									        	<small class="pull-right text-muted">
									        		<?php echo e($message->created_at->diffForHumans()); ?>

									        	</small>
									        </p>
									    </div>
									<?php else: ?>
										<?php if($message->from_id == $user->id): ?>
											<div class="msg-right msg">
										    	<p class="mb-0">
										    		<small><b>Me</b></small> <br>
										        	<small><?php echo e($message->message); ?></small> <br>
										        	<small class="pull-right">
										        		<?php echo e($message->created_at->diffForHumans()); ?>

										        	</small>
										    	</p>
										    </div>
										<?php else: ?>
											<div class="msg-left msg">
										    	<p class="mb-0">
										    		<small><b><?php echo e($message->sender->name); ?></b></small> <br>
										        	<small><?php echo e($message->message); ?></small> <br>
										        	<small class="text-muted">
										        		<?php echo e($message->created_at->diffForHumans()); ?>

										        	</small>
										    	</p>

										    </div>
										<?php endif; ?>
									<?php endif; ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<span class="no-conversation-selected centered">Write your first message</span>
							<?php endif; ?>
						</div>
					</div>
				</div>



				<div class="card">
					<div class="card-body row">
						<div class="col-sm-12">
							<form action="<?php echo e(route('user.message.new', ['id' => $current_conversation->id])); ?>" method="POST" id = "compose-message-form-">
								<?php echo csrf_field(); ?>
								<div class="form-group">
									<textarea name="message" id="" cols="30" rows="5" class="form-control" required="" placeholder="Type message here"></textarea>
								</div>

								<input type="hidden" id="conversation_url" value="<?php echo e(route('user.conversation.ajax', ['id' => $current_conversation->id])); ?>">

								<button class="btn btn-success pull-right" type="submit">Send <i class="fa fa-send"></i></button>
							</form>	
						</div>
						
					</div>
				</div>


			</div>


		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>