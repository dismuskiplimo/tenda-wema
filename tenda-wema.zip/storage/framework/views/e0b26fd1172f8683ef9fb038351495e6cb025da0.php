<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?>  (<?php echo e(number_format($donated_items->total())); ?>)</h3>

	            <?php if(count($donated_items)): ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Name</th>
								<th>Type</th>
								<th>Condition</th>
								<th>Category</th>
								<th>Donor</th>
								<th>Purchased</th>
								<th>Approved</th>
								<th>Delivered</th>
								<th></th>
								<th></th>
								
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $donated_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donated_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($donated_item->name); ?></td>
									<td><?php echo e($donated_item->type); ?></td>
									<td><?php echo e($donated_item->condition); ?></td>
									<td><?php echo e($donated_item->category ? $donated_item->category->name : 'N/A'); ?></td>
									<td><?php echo e($donated_item->donor ? $donated_item->donor->name : 'N/A'); ?></td>
									<td><?php echo e($donated_item->bought ? 'YES' : 'NO'); ?></td>
									<td><?php echo e($donated_item->approved ? 'YES' : 'NO'); ?></td>
									<td><?php echo e($donated_item->received ? 'YES' : 'NO'); ?></td>
									
									<td><a href="<?php echo e(route('admin.donated-item', ['id' => $donated_item->id])); ?>" class=""><i class="fa fa-eye"></i></a></td>
									<td class="">
										<?php if($donated_item->bought): ?>
											<?php if(!$donated_item->approved && !$donated_item->disapproved): ?>
												<a href=""  data-toggle = "modal" data-target = "#purchase-approve-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-success"><i class="fa fa-check" title="Approve Purchase"></i></a>

												<a href=""  data-toggle = "modal" data-target = "#purchase-disapprove-<?php echo e($donated_item->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times" title="Disapprove Purchase"></i></a>

												<?php echo $__env->make('pages.admin.modals.approve-purchase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												<?php echo $__env->make('pages.admin.modals.disapprove-purchase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php endif; ?>
										<?php endif; ?>

									</td>
									
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($donated_items->links()); ?>

	            <?php else: ?>
					No <?php echo e($title); ?>

	            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>