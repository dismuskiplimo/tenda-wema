<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($title); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Account</li>
				<li class="active"><?php echo e($title); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row my-50">
			<div class="col-sm-3 text-center">
				<div class="card">
					<div class="card-body">
						<h4>AVALIABLE BALANCE</h4>
						<h2>
							<img src="<?php echo e(simba_coin()); ?>" alt="Simba Coin" class="size-30">
							<?php echo e(number_format($user->coins)); ?>

							<small>Simba Coins</small>
						</h2>

						<hr>

						<p>
							<strong>
								<?php echo e(number_format($user->accumulated_coins)); ?>

							</strong>

							 accumulated Simba Coins since joining <?php echo e(config('app.name')); ?>


						</p>
					</div>
				</div>

				
			</div>

			<div class="col-sm-9">
				<h4>HISTORY 
					<span class="pull-right">
						<?php if($coin_request): ?>
							<a href="#" class="btn btn-primary btn-block btn-xs">
								COIN PURCHASE REQUESTED, PLEASE WAIT FOR FEEDBACK FROM ADMIN
							</a>
						<?php else: ?>
							<a href="<?php echo e(route('user.purchase-coins')); ?>" class="btn btn-primary btn-block btn-lg" data-toggle="modal" data-target="#purchase-coins">
								<img src="<?php echo e(simba_coin()); ?>" alt="" class="size-20 mr-5"> 
								PURCHASE EXTRA COINS
							</a>
						<?php endif; ?>

					</span>
				</h4>

				<?php if($user->simba_coin_logs()->count()): ?>
					<table class="table table-hover">
						<thead>
							<tr>
								<th class="text-right">AMOUNT</th>
								
								<th class="">DESCRIPTION</th>
								<th class="text-right">BALANCE</th>
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $user->simba_coin_logs()->orderBy('created_at', 'DESC')->paginate(50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="<?php echo e($log->type == 'credit' ? 'text-success' : 'text-danger'); ?>">
									<td class="text-right">
										<?php echo e($log->type == 'debit' ? '- ' : '+ '); ?> <?php echo e(number_format($log->coins)); ?> 
										<img src="<?php echo e(simba_coin()); ?>" alt="Simba Coin" class="size-20 mtn-4">
									</td>
									
									<td><?php echo e($log->message); ?></td>
									<td class="text-right">
										<?php echo e(number_format($log->current_balance)); ?> 
										<img src="<?php echo e(simba_coin()); ?>" alt="Simba Coin" class="size-20 mtn-4">
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($user->simba_coin_logs()->orderBy('created_at', 'DESC')->paginate(50)->links()); ?>

					
				<?php else: ?>
					No Transaction History
				<?php endif; ?>
			</div>
		</div>
	</div>
	
	<?php echo $__env->make('pages.user.modals.buy-coins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>