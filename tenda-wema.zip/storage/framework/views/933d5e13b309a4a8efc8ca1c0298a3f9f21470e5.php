<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"><?php echo e($title); ?>(<?php echo e(number_format($deeds->total())); ?>)</h3>

	            <?php if(count($deeds)): ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Deed</th>
								<th>Location</th>
								<th>Date</th>
								<th>User</th>
								<th>Approved</th>
								<th></th>
								<th></th>
								
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $deeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($deed->name); ?></td>
									<td><?php echo e($deed->location); ?></td>
									<td><?php echo e($deed->performed_at); ?></td>
									<td><?php echo e($deed->user->name); ?></td>
									<td><?php echo e($deed->approved ? 'YES' : 'NO'); ?></td>
									<td><a href="<?php echo e(route('admin.deed', ['id' => $deed->id])); ?>" class=""><i class="fa fa-eye"></i></a></td>
									<td class="">
										<?php if($deed->approved): ?>
											<a href=""  data-toggle = "modal" data-target = "#deed-disapprove-<?php echo e($deed->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times" title="Disapprove Deed"></i></a>

											<?php echo $__env->make('pages.admin.modals.disapprove-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										<?php else: ?>
											<?php if($deed->disapproved): ?>
												<a href="" data-toggle = "modal" data-target = "#deed-approve-<?php echo e($deed->id); ?>"  class="btn btn-xs btn-success"><i class="fa fa-check" title="Approve Deed"></i></a>
											<?php else: ?>
												<a href="" data-toggle = "modal" data-target = "#deed-approve-<?php echo e($deed->id); ?>"  class="btn btn-xs btn-success"><i class="fa fa-check" title="Approve Deed"></i></a>

												<a href="" data-toggle = "modal" data-target = "#deed-disapprove-<?php echo e($deed->id); ?>" class="btn btn-xs btn-danger"><i class="fa fa-times" title="Disapprove Deed"></i></a>

												<?php echo $__env->make('pages.admin.modals.disapprove-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											<?php endif; ?>

											<?php echo $__env->make('pages.admin.modals.approve-deed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
											

										<?php endif; ?>

									</td>
									
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($deeds->links()); ?>

	            <?php else: ?>
					No <?php echo e($title); ?>

	            <?php endif; ?>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>