<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($user->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Users</li>
				<li class="active"><?php echo e($user->name); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row my-50">
			<div class="col-sm-3">
				<?php echo $__env->make('includes.user.profile-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>

			<div class="col-sm-9">
				<h4>
					REVIEWS (<?php echo e(number_format($reviews->total())); ?>)

					<?php if($logged_in): ?>
						<?php if(!$me): ?>
							<?php if(!$reviewed): ?>
								<a href="" class="button button-black pull-right mtn-10" data-toggle="modal" data-target="#review-user-modal">REVIEW <?php echo e($user->name); ?></a>
							<?php else: ?>
								<button type="button" class="button button-black pull-right mtn-10" disabled="">YOU HAVE ALREADY REVIEWED THIS USER</button>
							<?php endif; ?>
							
						<?php endif; ?>
						
					<?php else: ?>
						<a href="" class="button button-black pull-right mtn-10" data-toggle="modal" data-target="#login-modal">LOG IN TO REVIEW</a>
					<?php endif; ?>
				</h4>

				<?php if($reviews->total()): ?>
					<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card">
							<div class="card-body">
								<h5>
									<a href="<?php echo e(route('user.show', ['username' => $review->user ? $review->user->username : ''])); ?>">
										<img src="<?php echo e($review->user ? $review->user->profile_thumbnail() : ''); ?>" class="img-circle size-40 mr-10" alt=""> <?php echo e($review->user ? $review->user->name : ''); ?>

									</a>

									<?php for($count = 0; $count < $review->rating; $count++ ): ?>
										<i class="fa fa-star text-warning"></i>
									<?php endfor; ?>

									<small class="text-muted"><?php echo e(simple_datetime($review->created_at)); ?></small>
									
								</h5>

								
								<?php echo clean(nl2br($review->message)); ?>


								

								
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php echo e($reviews->links()); ?>

				<?php else: ?>
					No reviews yet
				<?php endif; ?>
			</div>
		</div>
	</div>
		

<?php if(!$reviewed): ?>
	<?php echo $__env->make('pages.user.modals.review-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(!$logged_in): ?>
	<?php echo $__env->make('pages.user.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>