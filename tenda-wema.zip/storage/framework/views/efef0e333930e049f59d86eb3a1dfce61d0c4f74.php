<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title full-width">
	            	<?php echo e($title); ?>

	            </h3>
	
				<?php if($reports->total()): ?>
					<div class="row">
						<div class="col-sm-12">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>Date</th>
										<th>Victim</th>
										<th>Reported By</th>
										<th>Reason</th>
										<th>Status</th>
										<th></th>
										
									</tr>
								</thead>

								<tbody>
									<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<tr>
											<td><?php echo e(simple_datetime($report->created_at)); ?></td>
											<td><a href="<?php echo e(route('admin.user', ['id' => $report->user->id])); ?>"><?php echo e($report->user->name); ?></a></td>
											<td><a href="<?php echo e(route('admin.user', ['id' => $report->reporter->id])); ?>"><?php echo e($report->reporter->name); ?></a></td>
											<td><?php echo e($report->report_type->description); ?></td>

											<td><?php echo e($report->status()); ?></td>
											
											<td><a href="<?php echo e(route('admin.users.reported-single', ['id' => $report->id])); ?>" class="btn btn-xs"><i class="fa fa-eye"></i></a></td>
												
										</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
							
						</div>
						
					</div>

					<?php echo e($reports->links()); ?>

					
				<?php else: ?>
					<i>No <?php echo e($title); ?></i>
				<?php endif; ?>
	            
	        </div>
	        
	    </div>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>