<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($title); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Account</li>
				<li class="active"><?php echo e($title); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-sm-offset-1 py-50">
				<?php if($notifications->total()): ?>
					<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="panel <?php echo e($notification->read ? '' : 'panel-primary'); ?> mb-20">
							<a href="<?php echo e(route('user.notification', ['id' => $notification->id])); ?>">
								<div class="panel-body">
									<p class="nobottommargin">
										<?php echo e($notification->message); ?> <br>
										<small class="pull-right"><?php echo e(simple_datetime($notification->created_at)); ?></small>
									</p>
								</div>	
							</a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<p class="text-center">No Notifications</p>
				<?php endif; ?>	
			</div>
		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>