<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($deed->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li><a href="<?php echo e(route('good-deeds')); ?>">Good Deeds</a></li>
				<li class="active"><?php echo e($deed->name); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-sm-offset-1 py-50">
				<div class="card">
					<div class="card-body">

						<div class="row">
							<div class="col-sm-6">
								<h4 class="mb-5 text-muted">GOOD DEED </h4> 
								<h4> <?php echo e($deed->name); ?> <br> 
									
									<small class="text-muted"><?php echo e(simple_datetime($deed->created_at)); ?></small>
								</h4>

								<h4 class="mb-0 text-muted">LOCATION</h4>
								<p><?php echo e($deed->location); ?></p>

								<h4 class="mb-0 text-muted">DESCRIPTION</h4>
								<?php echo clean(nl2br($deed->description)); ?>

								
								<?php if($mine): ?>
									<h4 class="mb-0 text-muted">CONTACTS</h4>
									<?php echo clean(nl2br($deed->contacts)); ?>

								<?php endif; ?>
							</div>

							<div class="col-sm-6">
								<?php
									if($deed->disapproved){
										$color = 'red';
										$text = 'NOT APPROVED';
									}else{
										$color = $deed->approved ? 'green' : 'orange';
										$text = $deed->approved ? 'APPROVED' : 'PENDING APPROVAL';
									}
									

									

								?>

								<h4 class="mb-10">DONE BY <span class="pull-right" style ="color:<?php echo e($color); ?>"><?php echo e($text); ?></span> </h4>
								<p>
									<a href="<?php echo e(route('user.show', ['username' => $deed->user ? $deed->user->username : ''])); ?>">
										<img src="<?php echo e($deed->user ? $deed->user->profile_thumbnail() : ''); ?>" alt="<?php echo e($deed->user ? $deed->user->name : ''); ?>" class="size-30 mr-10 img-circle"> 

										<i class="mt-10">
											<?php echo e($deed->user ? $deed->user->name : ''); ?>	
										</i>
										
									</a>
								</p>
								
								<h4 class="mb-5">EVIDENCE (<?php echo e(count($deed->images)); ?>)</h4>
								<?php if(count($deed->images)): ?>
									<div class="row">
										<?php
											$count = 0;
										?>

										<?php $__currentLoopData = $deed->images()->orderBy('created_at', 'DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php
												$count++;
											?>
											<div class="col-sm-4">
												<a data-fancybox="gallery" href="<?php echo e($image->image()); ?>">
													<img src="<?php echo e($image->thumbnail()); ?>" alt="<?php echo e($image->user ? $image->user->name : ''); ?>" class="img-responsive img-rounded">
												</a>
											</div>

											<?php if($count % 3 == 0): ?>
												</div>
												<div class="row mb-20">
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									</div>
									
								<?php else: ?>
									<p class="text-muted mb-0">No evidence attached</p>
								<?php endif; ?>
							</div>
						</div>

					</div>
				</div>
				
			</div>
		</div>
	</div>
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>