<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"> <?php echo e($title); ?> (<?php echo e(number_format($conversations->total())); ?>)</h3>
	            
	            <?php if($conversations->total()): ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Recepient</th>
								<th>Message</th>
								<th></th>
							</tr>
						</thead>

						<tbody>
							<?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
									if($conversation->from_admin)
										$recepient = $conversation->to;
									else{
										$recepient = $conversation->from;
									}

									$class = '';

									if($conversation->last_message){
										if($conversation->last_message->support && !$conversation->last_message->from_admin && !$conversation->last_message->read){
											$class = ' class="bg-light"';
										}

									}
								?>

								<tr<?php echo $class; ?>>
									<td><?php echo e($recepient->name); ?></td>
									
									<td>
										<?php echo e($conversation->last_message ? characters($conversation->last_message->message, 50) : 'No messages'); ?>

									</td>
									
									<td class="text-right"><a <?php echo $class; ?> href="<?php echo e(route('admin.message.view', ['id' => $conversation->id])); ?>"><i class="fa fa-eye"></i> View</a></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

					<?php echo e($conversations->links()); ?>

	            <?php else: ?>
					<p class="text-muted">No Conversations</p>
	            <?php endif; ?>
	        </div> 
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>