<?php $__env->startSection('content'); ?>
	<section id="page-title">

		<div class="container clearfix">
			<h1><?php echo e($user->name); ?></h1>
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
				<li>Users</li>
				<li class="active"><?php echo e($user->name); ?></li>
			</ol>
		</div>

	</section>

	<div class="container">
		<div class="row my-50">
			<div class="col-sm-3">
				<?php echo $__env->make('includes.user.profile-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>

			<div class="col-sm-9">
				<h4>DONATED ITEMS (<?php echo e(number_format($donated_items->total())); ?>)</h4>
				
				<?php if($donated_items->total()): ?>
					<div class="row">
						<?php $__currentLoopData = $donated_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<?php
							$banner = item_banner();

							if($item->images){
								$donated_item_image = $item->images()->first();

								if($donated_item_image){
									$banner 		= $donated_item_image->banner();
								}
								
							}
						?>

						<div class="col-sm-4">
							<div class="card">
								<div class="card-body">
									<a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>">
										<img src="<?php echo e($banner); ?>" alt="<?php echo e($item->name); ?>" class="img-responsive">
									</a>

									<h4 class="mt-10 mb-0">
										<a href="<?php echo e(route('donated-item.show', ['slug' => $item->slug])); ?>"><?php echo e(characters($item->name, 20)); ?></a>	
									</h4>

									<small class="text-muted"><?php echo e($item->category ? $item->category->name : ''); ?></small>
								</div>
							</div>
						</div>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

					<div class="row">
						<?php echo e($donated_items->links()); ?>

					</div>
				<?php else: ?>
					<p class="text-muted">No Items Donated</p>
				<?php endif; ?>

			</div>
		</div>
	</div>
		

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>