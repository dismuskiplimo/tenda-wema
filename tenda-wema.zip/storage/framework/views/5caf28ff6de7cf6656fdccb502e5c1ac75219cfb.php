<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title">
	            	<?php echo e($title); ?>, 

					<?php if(!$user->is_admin()): ?>
						<?php if($stars): ?>
							<?php for($i = 0; $i < $stars; $i++): ?>
								<i class="fa fa-star text-warning"></i>
							<?php endfor; ?>

							<small><i>(Rated by <?php echo e(number_format($user->reviews)); ?> Users)</i></small>
						<?php else: ?>
							<small class="text-muted"><i>User not reviewed yet</i></small>
						<?php endif; ?>
					<?php endif; ?>
	            </h3>

	            <?php if(!$user->closed && !$me): ?>
		            <p class="text-right mb-0">
		          		<?php if(!$user->verified): ?>
							<a href="" data-toggle="modal" data-target="#verify-user-<?php echo e($user->id); ?>" class="btn btn-xs btn-success">
			          			<i class="fa fa-certificate"></i> Verify User
			          		</a>
		          		<?php endif; ?>

		          		<a href="" data-toggle="modal" data-target="#close-account-<?php echo e($user->id); ?>" class="btn btn-xs btn-danger">
		          			<i class="fa fa-times"></i> Close Account
		          		</a>
		            </p>

		            <?php echo $__env->make('pages.admin.modals.close-account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		            <?php if(!$user->verified && !$me): ?>
						<?php echo $__env->make('pages.admin.modals.verify-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	          		<?php endif; ?>
	            <?php endif; ?>

	            <hr>

	            <div class="row">
	            	<div class="col-sm-3 text-center">
	            		<img src="<?php echo e($user->image()); ?>" alt="" class="size-150 mb-50">

	            		<p><strong><?php echo e($user->name); ?></strong></p>

						<p>
		            		<?php if(!$user->is_admin()): ?>
								<?php if($stars): ?>
									<?php for($i = 0; $i < $stars; $i++): ?>
										<i class="fa fa-star text-warning"></i>
									<?php endfor; ?>

									<br><small><i>(Rated by <?php echo e(number_format($user->reviews)); ?> Users)</i></small>
								<?php else: ?>
									<small class="text-muted"><i>User not reviewed yet</i></small>
								<?php endif; ?>
							<?php endif; ?>

						</p>

						<img src="<?php echo e($user->badge()); ?>" alt="" class="size-100 mt-20">

						<p><?php echo e($user->social_level); ?></p>


	            	</div>

	            	<div class="col-sm-9">
	            		<table class="table table-condensed table-striped">
	            			<tr>
	            				<th>Name</th>
	            				<td><?php echo e($user->name); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Username</th>
	            				<td><?php echo e($user->username); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Email</th>
	            				<td><?php echo e($user->email); ?></td>
	            			</tr>
							
							<tr>
	            				<th>Social Level</th>
	            				<td><?php echo e($user->social_level); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Social Level Attained At</th>
	            				<td><?php echo e(simple_datetime($user->social_level_attained_at)); ?></td>
	            			</tr>
	            			
	            			<tr>
	            				<th>Usertype</th>
	            				<td><?php echo e($user->usertype); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Date of Birth</th>
	            				<td><?php echo e(simple_date($user->dob)); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Last Seen</th>
	            				<td><?php echo e(simple_datetime($user->last_seen)); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Account Closed</th>
	            				<td><?php echo $user->closed ? '<span class = "text-danger">YES</span>' : '<span class ="text-success">NO</span>'; ?></td>
	            			</tr>

	            			<tr>
	            				<th>User Verified</th>
	            				<td><?php echo $user->verified ? '<span class ="text-success">YES</span>' : '<span class ="text-danger">NO</span>'; ?></td>
	            			</tr>

	            			<tr>
	            				<th>Account Suspended</th>
	            				<td><?php echo $user->suspended ? '<span class ="text-danger">YES</span>' : '<span class ="text-success">NO</span>'; ?></td>
	            			</tr>

	            			

	            			<tr>
	            				<th>About User</th>
	            				<td><?php echo e($user->about_me); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Email Confirmed</th>
	            				<td><?php echo $user->email_confirmed ? '<span class ="text-success">YES</span>' : '<span class ="text-danger">NO</span>'; ?></td>
	            			</tr>

	            			<tr>
	            				<th>Simba Coins Balance</th>
	            				<td><?php echo e($user->coins); ?></td>
	            			</tr>

	            			<tr>
	            				<th>Accomulated Simba Coins</th>
	            				<td><?php echo e($user->accumulated_coins); ?></td>
	            			</tr>

	            			

	            			
	            		</table>
	            	</div>
	            </div>  
	        </div> 

	        <?php if(!$user->is_admin()): ?>
				
				<div class="white-box">
		        	<?php
		        		$photos_count = $user->photos()->count();
		        	?>

		        	<h3 class="box-title">Photos (<?php echo e(number_format($photos_count)); ?>)</h3>
					
					<?php if($photos_count): ?>
						<div class="row">
							

							<?php $__currentLoopData = $user->photos()->orderBy('created_at', 'DESC')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<div class="col-sm-4 mb-20">
									<div class="thumbnail">
										<a data-fancybox="gallery" href="<?php echo e($photo->photo()); ?>">
											<img src="<?php echo e($photo->thumbnail()); ?>" alt="" class="img-responsive">
										</a>
									</div>
									
								</div>

								

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<div class="col-sm-12">
								<hr>
								<p class="text-right">
									<a href="<?php echo e(route('admin.user.photos', ['id' => $user->id])); ?>">See all photos for <?php echo e($user->name); ?></a>
								</p>	
							</div>

							
						</div>

						
					<?php else: ?>
						<i>No photos</i>
					<?php endif; ?>
		        </div>

				
				<div class="white-box">
		        	<?php
		        		$review_count = $user->reviews()->count();
		        	?>

		        	<h3 class="box-title">User Reviews (<?php echo e(number_format($review_count)); ?>)</h3>
					
					<?php if($review_count): ?>
						<div class="row">
							

							<?php $__currentLoopData = $user->reviews()->orderBy('created_at', 'DESC')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<div class="col-sm-12">
									<p>
										<a href="<?php echo e(route('admin.user', ['id' => $review->rater->id])); ?>"><strong><?php echo e($review->rater->name); ?></strong></a>, 
										
										<?php for($i = 0; $i < $review->rating; $i++): ?>
											<i class="fa fa-star text-warning"></i>
										<?php endfor; ?>
										, <small class="text-muted"><?php echo e(simple_datetime($review->created_at)); ?></small>
																				
									</p>

									<p><?php echo e($review->message); ?></p>

									<hr>
								</div>

								

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<div class="col-sm-12">
								
								<p class="text-right">
									<a href="<?php echo e(route('admin.user.reviews', ['id' => $user->id])); ?>">See all reviews for <?php echo e($user->name); ?></a>
								</p>	
							</div>

							
						</div>

						
					<?php else: ?>
						<i>No reviews</i>
					<?php endif; ?>
		        </div>
				
		        
		        <div class="white-box">
		        	<h3 class="box-title">Items Donated by <?php echo e($user->name); ?> (<?php echo e(number_format(count($user->donated_items))); ?>)</h3>
					
					<?php if(count($user->donated_items)): ?>
						<div class="row">
							<?php $__currentLoopData = $user->donated_items()->orderBy('created_at', 'DESC')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<?php
									$banner = item_banner();

									if($item->images){
										$donated_item_image = $item->images()->first();

										if($donated_item_image){
											$banner 		= $donated_item_image->banner();
										}
										
									}
								?>

								<div class="col-sm-4 mb-20">
									<div class="">
										<div class="">
											<div class="row">
												<div class="col-sm-4">
													<a href="<?php echo e(route('admin.donated-item', ['id' => $item->id])); ?>">
														<img src="<?php echo e($banner); ?>" alt="<?php echo e($item->name); ?>" class="img-responsive">
													</a>
												</div>

												<div class="col-sm-8">
													<h4 class="mt-10">
														<a href="<?php echo e(route('admin.donated-item', ['id' => $item->id])); ?>"><?php echo e(characters($item->name, 20)); ?></a>	
													</h4>

													<small class="text-muted"><?php echo e($item->category ? $item->category->name : ''); ?></small>
												</div>
											</div>
											

											
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<div class="col-sm-12">
								<hr>
								<p class="text-right">
									<a href="<?php echo e(route('admin.user.donated-items', ['id' => $user->id])); ?>">See all items donated by <?php echo e($user->name); ?></a>
								</p>	
							</div>

							
						</div>

						
					<?php else: ?>
						<i>No items donated</i>
					<?php endif; ?>
		        </div>

		        
		        <div class="white-box">
		        	<h3 class="box-title">Items Bought by <?php echo e($user->name); ?> (<?php echo e(number_format(count($user->bought_items))); ?>)</h3>
					
					<?php if(count($user->bought_items)): ?>
						<div class="row">
							<?php $__currentLoopData = $user->bought_items()->orderBy('created_at', 'DESC')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<?php
									$banner = item_banner();

									if($item->images){
										$donated_item_image = $item->images()->first();

										if($donated_item_image){
											$banner 		= $donated_item_image->banner();
										}
										
									}
								?>

								<div class="col-sm-4 mb-20">
									<div class="">
										<div class="">
											<div class="row">
												<div class="col-sm-4">
													<a href="<?php echo e(route('admin.donated-item', ['id' => $item->id])); ?>">
														<img src="<?php echo e($banner); ?>" alt="<?php echo e($item->name); ?>" class="img-responsive">
													</a>
												</div>

												<div class="col-sm-8">
													<h4 class="mt-10">
														<a href="<?php echo e(route('admin.donated-item', ['id' => $item->id])); ?>"><?php echo e(characters($item->name, 20)); ?></a>	
													</h4>

													<small class="text-muted"><?php echo e($item->category ? $item->category->name : ''); ?></small>
												</div>
											</div>
											

											
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<div class="col-sm-12">
								<hr>
								<p class="text-right">
									<a href="<?php echo e(route('admin.user.bought-items', ['id' => $user->id])); ?>">See all items bought by <?php echo e($user->name); ?></a>
								</p>	
							</div>

							
						</div>

						
					<?php else: ?>
						<i>No items bought</i>
					<?php endif; ?>
		        </div>

		        
		        <div class="white-box">
		        	<h3 class="box-title">Good Deeds by <?php echo e($user->name); ?> (<?php echo e(number_format(count($user->good_deeds))); ?>)</h3>
					
					<?php if(count($user->good_deeds)): ?>
						<div class="row">
							<?php $__currentLoopData = $user->good_deeds()->where('approved', 1)->orderBy('created_at', 'DESC')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<div class="col-sm-12 mb-20">
									<p>
										Deed : <strong><?php echo e($deed->name); ?></strong> <br>
										Location : <?php echo e($deed->location); ?> <br>
										Peformed at : <?php echo e(simple_datetime($deed->peformed_at)); ?> <br>
										Description : <?php echo e($deed->description); ?> <br>	
										Contacts : <?php echo e($deed->contacts); ?>	
									</p>
									
								</div>

								<hr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<div class="col-sm-12">
								<hr>
								<p class="text-right">
									<a href="<?php echo e(route('admin.user.good-deeds', ['id' => $user->id])); ?>">See all good deeds by <?php echo e($user->name); ?></a>
								</p>	
							</div>

							
						</div>
						
					<?php else: ?>
						<i>No good deeds reported</i>
					<?php endif; ?>
		        </div>

		        
		        <div class="white-box">
		        	<h3 class="box-title">Simba Coin Log (<?php echo e(number_format(count($user->simba_coin_logs))); ?>)</h3>
					
					<?php if(count($user->simba_coin_logs)): ?>
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-striped">
									<thead>
										<tr>
											<th>Date</th>
											<th>Simba Coins</th>
											<th>Message</th>
											<th>Previous Balance</th>
											<th>New Balance</th>
											
											
										</tr>
									</thead>

									<tbody>
										<?php $__currentLoopData = $user->simba_coin_logs()->orderBy('created_at', 'DESC')->limit(25)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
											<tr>
												<td><?php echo e(simple_datetime($log->created_at)); ?></td>
												<td>
													<?php
														if($log->type == 'credit'){
															$class = 'text-success';	
														}else{
															$class = 'text-danger';
														}
													?>

													<span class="<?php echo e($class); ?>">
														<?php echo e($log->type == 'credit' ? '+' : '-'); ?> <?php echo e(number_format($log->coins)); ?>

													</span>
												</td>
												<td><?php echo e($log->message); ?></td>
												
												<td><?php echo e($log->previous_balance); ?></td>
												<td><?php echo e($log->current_balance); ?></td>
												
											</tr>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
								
								
								<div class="col-sm-12">
									<hr>
									<p class="text-right">
										<a href="<?php echo e(route('admin.user.simba-coin-logs', ['id' => $user->id])); ?>">See whole simba coin log</a>
									</p>	
								</div>
							</div>

							
						</div>
						
					<?php else: ?>
						<i>No simba coin logs</i>
					<?php endif; ?>
		        </div>

		        
		        <div class="white-box">
		        	<h3 class="box-title">Transactions (<?php echo e(number_format(count($user->transactions))); ?>)</h3>
					
					<?php if(count($user->transactions)): ?>
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-striped">
									<thead>
										<tr>
											<th>Date</th>
											<th>Transaction Code</th>
											<th>Amount</th>
											<th>Coins</th>
											<th>Medium</th>
											<th>Status</th>
											
										</tr>
									</thead>

									<tbody>
										<?php $__currentLoopData = $user->transactions()->orderBy('created_at', 'DESC')->limit(25)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
											<tr>
												<td><?php echo e(simple_datetime($transaction->created_at)); ?></td>
												<td><?php echo e($transaction->transaction_code); ?></td>
												<td><?php echo e($transaction->currency); ?> <?php echo e(number_format($transaction->amount)); ?></td>
												<td><?php echo e(number_format($transaction->coins)); ?> Simba Coins</td>
												<td><?php echo e($transaction->medium); ?></td>
												<td><?php echo e($transaction->status); ?></td>
												
											</tr>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
								
								
								<div class="col-sm-12">
									<hr>
									<p class="text-right">
										<a href="<?php echo e(route('admin.user.transactions', ['id' => $user->id])); ?>">See all transactions by <?php echo e($user->name); ?></a>
									</p>	
								</div>
							</div>

							
						</div>
						
					<?php else: ?>
						<i>No transactions</i>
					<?php endif; ?>
		        </div>

	        <?php endif; ?>
	        
	    </div>

	    
	</div>


	

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>