<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CoinPurchaseHistory extends Model
{
    //
}
