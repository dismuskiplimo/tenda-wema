<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SimbaCoinLog extends Model
{
    //
}
