@include('includes.admin.header')
@include('includes.admin.messages')

@yield('content')

@include('includes.admin.footer')