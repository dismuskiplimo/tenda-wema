@include('includes.admin.header')
@include('includes.admin.nav')
@include('includes.admin.messages')

@yield('content')

@include('includes.admin.plain-footer')