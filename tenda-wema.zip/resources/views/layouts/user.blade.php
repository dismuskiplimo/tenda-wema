@include('includes.user.header')
@include('includes.user.nav')
@include('includes.user.messages')

@yield('content')

@include('includes.user.footer')