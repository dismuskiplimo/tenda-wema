@extends('layouts.admin')

@section('title', $title)

@section('content')
	<div class="row">
	    <div class="col-md-12">
	        <div class="white-box">
	            <h3 class="box-title"></h3>
	            
	        </div> 
	        
	    </div>

	    
	</div>


	

	
@endsection