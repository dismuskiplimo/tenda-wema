<?php
	header('Location: public_html');